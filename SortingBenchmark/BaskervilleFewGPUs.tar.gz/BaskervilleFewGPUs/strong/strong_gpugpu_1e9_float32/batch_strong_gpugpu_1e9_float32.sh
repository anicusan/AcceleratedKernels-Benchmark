#!/bin/bash
#SBATCH --qos=bham
#SBATCH --ntasks=8
#SBATCH --ntasks-per-node=1
#SBATCH --gres=gpu:1
#SBATCH --constraint=a100_40
#SBATCH --mem-per-cpu=100G
#SBATCH --time=1:00:00
#SBATCH --output=batch_strong_gpugpu_1e9_float32_%j.out


module purge
module load baskerville
module load bask-apps/live
module load OSU-Micro-Benchmarks/7.2-gompi-2023a-CUDA-12.1.1


JULIA_PROJECT=/bask/projects/m/morriajz-julia/Benchmarking/JuliaBench
export PATH=$PATH:$HOME.julia/bin
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/bask/projects/m/morriajz-julia/Benchmarking/BaskervilleUtilitiesCollection/install/lib


mpiexec -n 2 julia --project=$JULIA_PROJECT strong_gpugpu_1e9_float32.jl
mpiexec -n 3 julia --project=$JULIA_PROJECT strong_gpugpu_1e9_float32.jl
mpiexec -n 4 julia --project=$JULIA_PROJECT strong_gpugpu_1e9_float32.jl
mpiexec -n 5 julia --project=$JULIA_PROJECT strong_gpugpu_1e9_float32.jl
mpiexec -n 6 julia --project=$JULIA_PROJECT strong_gpugpu_1e9_float32.jl
mpiexec -n 7 julia --project=$JULIA_PROJECT strong_gpugpu_1e9_float32.jl
mpiexec -n 8 julia --project=$JULIA_PROJECT strong_gpugpu_1e9_float32.jl


