#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# File   : plot.py
# License: GNU v3.0
# Author : Andrei Leonard Nicusan <a.l.nicusan@bham.ac.uk>
# Date   : 18.04.2024


import toml
import numpy as np

import matplotlib.pyplot as plt
import seaborn as sns
sns.set_style("whitegrid")

import matplotlib
font = {'size'   : 20}
matplotlib.rc('font', **font)


with open("strong.toml") as f:
    data = toml.load(f)


nums = ["1e9"]
dtypes = ["float32"]
archs = ["cpucpu", "gpucpu", "gpugpu"]

arch_names = ["CPU-CPU", "GPU-CPU (MPI / CPU Transfer)", "GPU-GPU (MPI / GPUDirect)"]


for num in nums:
    for dtype in dtypes:

        fig, ax = plt.subplots(figsize=(10, 10))

        for i, arch in enumerate(archs):

            key = f"{arch}_{num}_{dtype}"
            x = data[key]["N"]
            y = np.array(data[key]["median"]) / 1e9
            # yerr = np.array(data[key]["std"]) / data[key]["median"]
            y = y / y[0]
            ax.plot(x, y, "-o", label = arch_names[i])

        # ax.plot([0, 6], [1, 1], "--k")

        # ax.set_xscale('log')
        # ax.set_yscale('log')
        ax.legend()
        # ax.grid(True, which="both", ls="-")
        ax.set(
            xlabel="Number of Nodes (#)",
            ylabel="Strong Scaling Efficiency",
            title=f"Number of Elements: {num} | DType: {dtype}",
            ylim=[0, 1],
        )

        fig.show()
        fig.savefig(f"plots/strong_{num}_{dtype}.png", dpi=300)


