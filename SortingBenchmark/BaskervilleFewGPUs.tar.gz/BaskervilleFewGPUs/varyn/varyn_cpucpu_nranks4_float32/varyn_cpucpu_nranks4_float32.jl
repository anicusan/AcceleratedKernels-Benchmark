# Vary N
# 4 ranks
# Float32


using MPI
using Random

using BenchmarkTools
using FileIO

using MPISort


# Initialise MPI, get communicator for all ranks, rank index, number of ranks
MPI.Init()

comm = MPI.COMM_WORLD
rank = MPI.Comm_rank(comm)
nranks = MPI.Comm_size(comm)


# Generate local array on each MPI rank - even with different number of elements
rng = Xoshiro(rank)

N = [1_000, 10_000, 100_000, 1_000_000, 10_000_000, 100_000_000, 1_000_000_000]
benchmarks = []
for num_elements in N
    alg = SIHSort(comm)
    bench = @benchmark mpisort!(v, alg=$alg) setup=(v = rand($rng, Float32, $num_elements)) samples=5 evals=1 seconds=600
    push!(benchmarks, bench)
end


if rank == 0
    save("varyn_cpucpu_nranks4_float32_benchmarks.jld2", Dict("benchmarks" => benchmarks, "N" => N))
end
