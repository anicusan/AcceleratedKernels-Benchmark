# File   : extract.jl
# License: GNU v3.0
# Author : Andrei Leonard Nicusan <a.l.nicusan@bham.ac.uk>
# Date   : 18.04.2024


using BenchmarkTools
using TOML


ranks = ["4", "8"]
dtypes = ["float32", "int64"]
archs = ["cpucpu", "gpucpu", "gpugpu"]


collected = Dict{String, Any}(
    "N" => [1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000],
)

for rank in ranks
    for dtype in dtypes
        for arch in archs

            filepath = "varyn_$(arch)_nranks$(rank)_$(dtype)"
            filepath = "$filepath/$(filepath)_benchmarks.jld2"

            benchmarks = load(filepath)["benchmarks"]
            key = "$(arch)_$(rank)_$(dtype)"
            value = [
                Dict("median" => median(b).time, "std" => std(b).time)
                for b in benchmarks
            ]

            collected[key] = value
        end
    end
end


open("varyn.toml", "w") do io
    TOML.print(io, collected)
end

