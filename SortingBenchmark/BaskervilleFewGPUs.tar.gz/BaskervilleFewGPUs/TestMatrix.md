# Varying N
- 4 and 8 ranks
- N: 1e3, 1e4, 1e5, 1e6, 1e7, 1e8, 1e9, 4e9
- Float32
- CPU-CPU, GPU-CPU-GPU, GPU-GPU

# Weak Scaling
- Ranks: 2, 3, 4, 5, 6, 7, 8, 9, 10
- N: 250e6 (1GB), 2e9 (8GB) (per processor)
- Float32
- CPU-CPU, GPU-CPU-GPU, GPU-GPU

# Strong Scaling
- Ranks: 2, 3, 4, 5, 6, 7, 8, 9, 10
- N: 250e6 (1GB), 2e9 (8GB) (total)
- Float32
- CPU-CPU, GPU-CPU-GPU, GPU-GPU



