# File   : extract.jl
# License: GNU v3.0
# Author : Andrei Leonard Nicusan <a.l.nicusan@bham.ac.uk>
# Date   : 18.04.2024


using BenchmarkTools
using FileIO
using TOML


nums = ["1e6", "1e9"]
dtypes = ["float32"]
archs = ["cpucpu", "gpucpu", "gpugpu"]

collected = Dict()

for num in nums
    for dtype in dtypes
        for arch in archs

            filepath = "weak_$(arch)_$(num)_$(dtype)"
            filepath = "$filepath/$(filepath)_benchmarks.jld2"

            benchmarks = load(filepath) |> collect
            sort!(benchmarks, by=b->parse(Int, b.first))

            key = "$(arch)_$(num)_$(dtype)"
            value = Dict(
                "N" => [b.first for b in benchmarks],
                "median" => [median(b.second).time for b in benchmarks],
                "std" => [std(b.second).time for b in benchmarks],
            )

            collected[key] = value
        end
    end
end


open("weak.toml", "w") do io
    TOML.print(io, collected)
end

