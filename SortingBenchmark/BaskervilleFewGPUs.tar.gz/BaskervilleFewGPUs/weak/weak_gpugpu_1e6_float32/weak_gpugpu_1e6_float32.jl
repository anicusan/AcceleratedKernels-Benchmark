# Weak scaling
# N = 1_000_000
# Float32


using MPI
using Random

using BenchmarkTools
using FileIO

using MPIGPUSort
using CUDA


# Initialise MPI, get communicator for all ranks, rank index, number of ranks
MPI.Init()

comm = MPI.COMM_WORLD
rank = MPI.Comm_rank(comm)
nranks = MPI.Comm_size(comm)


@show nranks


# Generate local array on each MPI rank - even with different number of elements
rng = Xoshiro(rank)
num_elements = 1_000_000

alg = SIHSort(comm)
bench = @benchmark mpigpusort!(v, alg=$alg) setup=(v = CuArray(rand($rng, Float32, $num_elements))) samples=20 evals=1 seconds=600


if rank == 0
    filename = "weak_gpugpu_1e6_float32_benchmarks.jld2"
    benchmarks = isfile(filename) ? load(filename) : Dict()
    benchmarks[string(nranks)] = bench
    save(filename, benchmarks)
end
