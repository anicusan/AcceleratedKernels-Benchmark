
import subprocess


def system(cmd):
    print(cmd)
    return subprocess.run(cmd, shell=True, check=True, capture_output=True, text=True)


jobs = system("squeue").stdout.split("\n")[1:-1]
jobs = sorted(jobs, key=lambda line: int(line.split()[0]))

with open("jobs.txt", "w") as f:
    f.write("\n".join(jobs))


