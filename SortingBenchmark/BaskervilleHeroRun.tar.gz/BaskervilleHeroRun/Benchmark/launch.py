#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# File   : launch.py
# License: GNU v3.0
# Author : Andrei Leonard Nicusan <a.l.nicusan@bham.ac.uk>
# Date   : 23.06.2024


import subprocess


def system(cmd):
    print(cmd)
    subprocess.run(cmd, shell=True, check=True)


# Possible benchmark permutations
algorithms = [
    # "cpu_cpu_base",
    "gpu_gpu_akm",
    "gpu_gpu_bucr",
    "gpu_gpu_bucm",
    "gpu_cpu_akm",
    "gpu_cpu_bucr",
    "gpu_cpu_bucm",
]

distributions = ["random", "normal"]

data_types = ["Int16", "Int32", "Int64", "Int128", "Float32", "Float64"]

data_sizes = [0.1, 1, 10, 100, 1000, 5000]      # MB

# per_nodes = [1, 2, 3, 4]
# num_nodes = list(range(1, 53))
# num_tasks = list(range(1, 33)) + list(range(40, 101, 10)) + list(range(120, 201, 20))
num_tasks = list(range(1, 17)) + list(range(18, 33, 2)) + list(range(40, 101, 10)) + list(range(120, 201, 20))


# # Launch a one-off
# distribution = distributions[0]
# data_size = data_sizes[-1]
# n = num_tasks[-1]
# algorithm = algorithms[1]
# data_type = data_types[3]
# log = f"logs/{algorithm}_{n}_{distribution}_{data_type}_{data_size}_slurm_%j.out"
# system((
#     f"sbatch --ntasks={n} --output={log} batch_run.sh "
#     f"{algorithm} {distribution} {data_type} {data_size}"
# ))


# Weak scaling / Vary N tests
distribution = distributions[0]
for data_size in data_sizes[4:5]:
    for n in num_tasks[-5:]:
        for algorithm in algorithms:
            log = f"logs/{algorithm}_{n}_{distribution}_DTYPE_{data_size}_slurm_%j.out"
            system((
                f"sbatch --ntasks={n} --output={log} batch_run.sh "
                f"{algorithm} {distribution} DTYPE_PLACEHOLDER {data_size}"
            ))


