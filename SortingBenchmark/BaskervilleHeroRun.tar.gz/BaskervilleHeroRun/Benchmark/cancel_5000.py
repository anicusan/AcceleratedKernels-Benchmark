
import subprocess


def system(cmd):
    print(cmd)
    return subprocess.run(cmd, shell=True, check=True, capture_output=True, text=True)



with open("jobs.txt") as f:
    jobs = f.readlines()

job_ids = [job.split()[0] for job in jobs]


for job_id in job_ids:
    out = system(f"scontrol show job {job_id}").stdout
    if "200_random_DTYPE_10_" in out:
        system(f"scancel {job_id}")



