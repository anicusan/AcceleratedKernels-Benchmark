

import MPI
using Random
using DelimitedFiles

using CUDA
using MPISort
using MPIGPUCPUSort
using BUC
import AcceleratedKernels as AK


# Initialise MPI, get communicator for all ranks, rank index, number of ranks
MPI.Init()

comm = MPI.COMM_WORLD
rank = MPI.Comm_rank(comm)
nranks = MPI.Comm_size(comm)


# Algorithms
function cpu_cpu_base(data_host)
    data = Array(data_host)

    # All ranks start simultaneously
    MPI.Barrier(comm)
    stats = @timed mpisort!(data)

    stats
end

function gpu_gpu_akm(data_host)
    data = CuArray(data_host)
    temp = similar(data, length(data) + length(data) ÷ 2)

    # All ranks start simultaneously
    MPI.Barrier(comm)
    stats = @timed mpisort!(
        data,
        sorter! = v -> AK.merge_sort!(v, block_size=512, temp=@view(temp[1:length(v)])),
    )

    CUDA.unsafe_free!(data)
    CUDA.unsafe_free!(temp)

    stats
end

function gpu_gpu_bucr(data_host)
    data = CuArray(data_host)

    # All ranks start simultaneously
    MPI.Barrier(comm)
    stats = @timed mpisort!(
        data,
        sorter! = v -> buc_sort!(v),
    )

    CUDA.unsafe_free!(data)

    stats
end

function gpu_gpu_bucm(data_host)
    data = CuArray(data_host)

    # All ranks start simultaneously
    MPI.Barrier(comm)
    stats = @timed mpisort!(
        data,
        sorter! = v -> buc_mergesort!(v),
    )

    CUDA.unsafe_free!(data)

    stats
end

function gpu_cpu_akm(data_host)
    data = CuArray(data_host)
    temp = similar(data, length(data) + length(data) ÷ 2)

    # All ranks start simultaneously
    MPI.Barrier(comm)
    stats = @timed mpigpucpusort!(
        data,
        sorter! = v -> AK.merge_sort!(v, block_size=512, temp=@view(temp[1:length(v)])),
    )

    CUDA.unsafe_free!(data)
    CUDA.unsafe_free!(temp)

    stats
end

function gpu_cpu_bucr(data_host)
    data = CuArray(data_host)

    # All ranks start simultaneously
    MPI.Barrier(comm)
    stats = @timed mpigpucpusort!(
        data,
        sorter! = v -> buc_sort!(v),
    )

    CUDA.unsafe_free!(data)

    stats
end

function gpu_cpu_bucm(data_host)
    data = CuArray(data_host)

    # All ranks start simultaneously
    MPI.Barrier(comm)
    stats = @timed mpigpucpusort!(
        data,
        sorter! = v -> buc_mergesort!(v),
    )

    CUDA.unsafe_free!(data)

    stats
end


# Main benchmarking function based on a given algorithm! (the function itself)
function sort_bench(algorithm!, data_host)

    # Save times and GC times
    times = Vector{Tuple{Float64, Float64}}(undef, 0)

    # Run benchmark a number of times
    num_benchmarks = length(data_host) < 10_000_000 ? 32 : 16
    for i in 1:num_benchmarks
        GC.enable(false)
        stats = algorithm!(data_host)
        GC.enable(true)
        GC.gc()
        push!(times, (stats.time, stats.gctime))

        rank == 0 && println("Benchmark iteration $i: $(times[end])")

        # Write results as they come
        algname = String(Symbol(algorithm!))
        filename = "results_strong/$(algname)_nranks$(nranks)_rank$(rank)_dtype$(data_type)_dsize$(data_size)MB.csv"
        open(filename, "w") do io
            writedlm(io, times, ',')
        end
    end
end


# Benchmark variables set via command-line:
#   $1 = algorithm = cpu_cpu_base / gpu_{g|c}pu_akm / gpu_{g|c}pu_bucr / gpu_{g|c}pu_bucm
#   $2 = distribution = random / normal
#   $3 = data_type = Int16 / Int32 / Int64 / Int128 / Float32 / Float64
#   $4 = data_size (per rank) = <N> MB
algorithm! = eval(Symbol(ARGS[1]))
distribution = ARGS[2]
@assert distribution == "random" || distribution == "normal"

data_type = eval(Symbol(ARGS[3]))

data_size = parse(Float64, ARGS[4])
num_elements = trunc(Int, data_size * 1e6 / sizeof(data_type))


# Print stats on rank 0
if rank == 0
    @show nranks ARGS algorithm! distribution data_type data_size num_elements
end


# Generate random data on host
Random.seed!(0)
if distribution == "random"
    data_host = rand(data_type, num_elements)
elseif distribution == "normal"
    data_host = rand(data_type, num_elements)
else
    throw(ArgumentError("Unsupported distribution=$distribution"))
end


# Run benchmark for given algorithm
sort_bench(algorithm!, data_host)

