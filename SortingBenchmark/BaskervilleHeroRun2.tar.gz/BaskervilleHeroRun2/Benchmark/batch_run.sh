#!/bin/bash
#SBATCH --time=1:00:00

#SBATCH --reservation=kit-hero
#SBATCH --qos=bham
#SBATCH --account=morriajz-julia

# We have 52 nodes with 4 GPUs each in total
#SBATCH --gpus-per-task 1
#SBATCH --mem-per-gpu 120G

# Set from the command-line
# #SBATCH --tasks-per-node 4
# #SBATCH --nodes 2


module purge
module load baskerville
module load bask-apps/live
module load OSU-Micro-Benchmarks/7.2-gompi-2023a-CUDA-12.1.1


# On Baskerville
JULIA_PROJECT=/bask/projects/m/morriajz-julia/Benchmarking/JuliaBench3/JuliaProject

# First compile BUC/CMakeLists.txt!
export PATH=$PATH:$HOME.julia/bin
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$JULIA_PROJECT/BUC/install/lib


# Benchmark variables set via command-line:
#   $1 = algorithm = cpu_cpu_base / gpu_{g|c}pu_akm / gpu_{g|c}pu_bucr / gpu_{g|c}pu_bucm
#   $2 = distribution = random / normal
#   $3 = data_type = Int16 / Int32 / Int64 / Int128 / Float32 / Float64
#   $4 = data_size (per rank) = <N> MB
# srun julia --project=$JULIA_PROJECT benchmark.jl $1 random Int16 $4
srun julia --project=$JULIA_PROJECT benchmark_nogc.jl $1 random Int32 $4
srun julia --project=$JULIA_PROJECT benchmark_nogc.jl $1 random Int64 $4
srun julia --project=$JULIA_PROJECT benchmark_nogc.jl $1 random Int128 $4
srun julia --project=$JULIA_PROJECT benchmark_nogc.jl $1 random Float32 $4
srun julia --project=$JULIA_PROJECT benchmark_nogc.jl $1 random Float64 $4


