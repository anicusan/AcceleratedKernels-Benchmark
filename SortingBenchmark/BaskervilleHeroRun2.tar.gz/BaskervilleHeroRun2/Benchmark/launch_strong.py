#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# File   : launch.py
# License: GNU v3.0
# Author : Andrei Leonard Nicusan <a.l.nicusan@bham.ac.uk>
# Date   : 23.06.2024


import subprocess


def system(cmd):
    print(cmd)
    subprocess.run(cmd, shell=True, check=True)


# Possible benchmark permutations
algorithms = [
    # "cpu_cpu_base",
    "gpu_gpu_akm",
    "gpu_gpu_bucr",
    "gpu_gpu_bucm",
    "gpu_cpu_akm",
    "gpu_cpu_bucr",
    "gpu_cpu_bucm",
]

distributions = ["random", "normal"]

# data_types = ["Int16", "Int32", "Int64", "Int128", "Float32", "Float64"]

# data_sizes = [0.1, 1, 10, 100, 1000, 5000]      # MB

# per_nodes = [1, 2, 3, 4]
# num_nodes = list(range(1, 53))
# num_tasks = list(range(1, 33)) + list(range(40, 101, 10)) + list(range(120, 201, 20))


# # Launch a one-off
# distribution = distributions[0]
# data_size = 8000
# n = 2
# algorithm = "gpu_gpu_akm"
# log = f"logs_strong/{algorithm}_{n}_{distribution}_DTYPE_{data_size}_slurm_%j.out"
# system((
#     f"sbatch --ntasks={n} --output={log} batch_run.sh "
#     f"{algorithm} {distribution} DTYPE_PLACEHOLDER {data_size}"
# ))


# Strong scaling with 16GB of data split across 2-200 GPUs
# total_data_size = 16_000    # MB
total_data_size = 200       # MB
num_tasks = list(range(2, 17)) + list(range(18, 33, 2)) + list(range(40, 101, 10)) + list(range(120, 201, 20))
# num_tasks = [2, 4, 8, 16, 32, 64, 128, 200]
distribution = distributions[0]
for n in num_tasks:
    for algorithm in algorithms:
        data_size = total_data_size / n
        log = f"logs_strong/{algorithm}_{n}_{distribution}_DTYPE_{data_size}_slurm_%j.out"
        system((
            f"sbatch --ntasks={n} --output={log} batch_run_strong.sh "
            f"{algorithm} {distribution} DTYPE_PLACEHOLDER {data_size}"
        ))



# # Weak scaling / Vary N tests
# distribution = distributions[0]
# for data_size in data_sizes[5:6]:
#     for n in num_tasks:
#         for algorithm in algorithms:
#             log = f"logs/{algorithm}_{n}_{distribution}_DTYPE_{data_size}_slurm_%j.out"
#             system((
#                 f"sbatch --ntasks={n} --output={log} batch_run.sh "
#                 f"{algorithm} {distribution} DTYPE_PLACEHOLDER {data_size}"
#             ))


